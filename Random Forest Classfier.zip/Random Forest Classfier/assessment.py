
from pymongo import MongoClient                                                         #This MongoClient module is used to connect to the MongoDB database                                                    
import json                                                                             #The json module is used to convert the data to json format 
import seaborn as sns                                                         #The seaborn module is used to visualize the data
import matplotlib.pyplot as plt                                            #The matplotlib.pyplot module is used to visualize the data
import pandas as pd                                                            #The pandas module is used to read the csv file  
import numpy as np                                                               #The numpy module is used to perform mathematical operations on the data
from sklearn.model_selection import train_test_split                            #The train_test_split module is used to split the data into training and testing data   
from sklearn.ensemble import RandomForestClassifier                     #The RandomForestClassifier module is used to create a random forest classifier
from sklearn.metrics import accuracy_score, f1_score, roc_auc_score     #The accuracy_score, f1_score, roc_auc_score modules are used to calculate the accuracy, f1 score and roc auc score of the model
import tkinter




class DataModelling:                                                                                                
    def __init__(self, client, dbObject, test_jsonData, train_jsonData, test_data, train_data, test_collection, train_collection):          #This is the constructor method that initializes the variables                                             
        self.client = client                                                             #This code creates a client object that connects to the MongoDB database                      
        self.dbObject = dbObject                                #This code creates a database object that connects to the db1 database
        self.test_jsonData = test_jsonData              #This code creates a test_jsonData object that stores the test data in json format
        self.train_jsonData = train_jsonData        #This code creates a train_jsonData object that stores the train data in json format
        self.test_data = test_data                      #This code creates a test_data object that stores the test data in csv format                                                                       
        self.train_data = train_data            #This code creates a train_data object that stores the train data in csv format
        self.test_collection = test_collection                  #This code creates a test_collection object that stores the test data as a collection in the database
        self.train_collection = train_collection                #This code creates a train_collection object that stores the train data as a collection in the database
        

    def create_database(self):              
        #This code creates a database object that connects to the db1 database
        self.dbObject = self.client["TitanicPrediction"]    

        #This code inserts the test and train data as a new collection into the database                                                   
        #self.dbObject.test_collection.insert_many(self.test_jsonData)                                            
        #self.dbObject.train_collection.insert_many(self.train_jsonData)       

        #This code prints the names of the collections in the database                                
        return self.dbObject.list_collection_names()                                                     

    def import_collection(self):

        #This code imports the test and train data from the database as collections            
        self.test_dataset = self.dbObject.test_collection
        self.train_dataset = self.dbObject.train_collection

        #This code returns the test and train data as collections to the main function
        return self.test_dataset, self.train_dataset

    def convert_collection_to_dataframe(self):     
        #Convert the test and train data from the database into dataframes
        self.test = pd.DataFrame(list(self.test_dataset.find()))
        self.train = pd.DataFrame(list(self.train_dataset.find()))

        #This code returns and prints the test and train dataframes to the main function
        return self.test, self.train
        print(self.train.describe())

    def data_gathering_and_understanding(self):     #This method assesses the train and test data  and prints a summary of the data
        print(self.test.shape, self.train.shape)                                                  #This code prints the shape of the data
        print(self.train.info())

    def exploring_data_and_preparing_for_analysis(self):    
        print(self.train['Survived'].value_counts(normalize=False))

        #Create a new column called 'Survived' in the test data and fill it with 'test' values
        self.test['Survived'] = 'test'

        #Concatenate the train and test data
        self.data = pd.concat([self.train, self.test]).reset_index(drop=True)

        #Drop the _id, 'PassengerId', 'Name', 'Ticket', 'Cabin' columns
        self.data.drop(['_id', 'Name','PassengerId','Ticket','Cabin'], axis=1, inplace=True)

        #Fill in the missing values in the age and fare columns with -999
        cols = ['Age', 'Fare']
        for col in cols:
            self.data[col].fillna(-999, inplace=True)

        #Fill in the missing values in the embarked column with the mode
        self.data['Embarked'].fillna(self.data['Embarked'].mode()[0], inplace=True)

        #Encode the categorical data "Sex" and "Embarked" using one-hot encoding
        cats = ['Sex', 'Embarked']
        for cat in cats:
            self.data[cat] = pd.factorize(self.data[cat])[0]

        #Split the data into train and test
        self.train = self.data[self.data['Survived'] != 'test'].reset_index(drop = True)
        self.test = self.data[self.data['Survived'] == 'test'].reset_index(drop = True)
        
        #Separate the target variable from the train dataset
        self.X = self.train.drop(['Survived'], axis=1)
        self.y = self.train['Survived']
        self.y = self.y.astype('int')

        return self.X, self.y, self.test


    def data_visualization(self):   #This method encapsulates the code that visualizes the data
        sns.countplot(x='Survived', data=self.train)
        plt.show()
    

    def model_fitting(self):                     
        #Split the data into training and testing data
        self.X_train, self.X_test, self.y_train, self.y_test = train_test_split(self.X, self.y, test_size=0.2, random_state=12)

        #Create a random forest classifier
        self.model = RandomForestClassifier()

        #Fit the model to the training data
        self.model.fit(self.X_train, self.y_train)

        #Predict the target variable for the test data
        self.y_pred = self.model.predict(self.X_test)

        #This code checks the probability of the target variable being 1
        self.y_pred_prob = self.model.predict_proba(self.X_test)[:,1]

        #This code prints the accuracy score of the model                     
        return self.y_pred, self.y_pred_prob

    def model_evaluation(self):    
        #This code calculates the accuracy score of the model
        self.accuracy = accuracy_score(self.y_test, self.y_pred)  

        #This code calculates the f1 score of the model  
        self.f1 = f1_score(self.y_test, self.y_pred)

        #This code calculates the roc auc score of the model
        self.roc_auc = roc_auc_score(self.y_test, self.y_pred_prob)

        #This code prints the accuracy, f1 score and roc auc score of the model
        return self.accuracy, self.f1, self.roc_auc

    def print_results(self):    #This method encapsulates the code that prints the results of the model evaluation
        print('Accuracy: ', self.accuracy)
        print('F1 Score: ', self.f1)
        print('ROC AUC Score: ', self.roc_auc)


#This function encapsulates the code that calls the methods in the TitanicPrediction class
def main(): 

    #This code creates a client object that connects to the database   
    client = MongoClient("mongodb://127.0.0.1:27017")                                       
    
    #This code creates a database object that connects to the db1 database
    dbObject = client["TitanicPrediction"]  

    #This code reads the csv file and stores it in the data variable                                                
    test_data = pd.read_csv('test.csv') 
    
    #This code reads the csv file and stores it in the data variable                                                   
    train_data = pd.read_csv('train.csv')                                                         

    #This code converts the data to json format 
    test_jsonData = json.loads(test_data.to_json(orient='records'))                                
    train_jsonData = json.loads(train_data.to_json(orient='records'))                                

    #This code creates a collection object that connects to the train_collection collection      
    test_dataset = dbObject.test_collection                                                      
    train_dataset = dbObject.train_collection   

    #This code creates an object of the TitanicPrediction class                                              
    dataModelling = DataModelling(client, dbObject, test_jsonData, train_jsonData, test_data, train_data, test_dataset, train_dataset)  
    dataModelling.create_database()                                                       
    dataModelling.import_collection()                                                   
    dataModelling.convert_collection_to_dataframe()                                    
    dataModelling.data_gathering_and_understanding()                      
    dataModelling.exploring_data_and_preparing_for_analysis()         
    dataModelling.data_visualization()                                   
    dataModelling.model_fitting()                                        
    dataModelling.model_evaluation()                         
    dataModelling.print_results()                                          



class Authenticate:
    def __init__(self):
        self.mw = tkinter.Tk()                                                                                  #Create main window

        
        self.mw.title("Welcome to my Model!")                                                                   #Set title of main window

        self.top_frame = tkinter.Frame(self.mw)                                                                 #Create top frame    
        self.middle_frame = tkinter.Frame(self.mw)                                                              #Create middle frame
        self.bottom_frame = tkinter.Frame(self.mw)                                                              #Create bottom frame
        self.lowest_frame = tkinter.Frame(self.mw)                                                              #Create lowest frame

        self.username_label = tkinter.Label(self.top_frame, text = "Enter Username:")                           #Create description label for top fame
        self.username_entry = tkinter.Entry(self.top_frame, width= 25)                                          #Create StringVar object that will store the username

        self.password_label = tkinter.Label(self.middle_frame, text = "Enter Password")                         #Create result label for middle frame
        self.password_entry = tkinter.Entry(self.middle_frame, width= 25)                                       #Create StringVar object that will store the password

        self.continue_button = tkinter.Button(self.bottom_frame, text = "Continue", command=self.Checker)       #Create convert button for bottom frame      
        self.reset_button = tkinter.Button(self.bottom_frame, text = "Exit", command=self.Reset)                #Create exit button for bottom frame

        self.result = tkinter.StringVar()                                                                       #Create StringVar object that will store the total 

        self.result_label = tkinter.Label(self.lowest_frame, textvariable=self.result)                          #Create result label for lowest frame

        
        self.username_label.pack(side="left")                                                                   #Pack username label for top frame
        self.username_entry.pack(side="left")                                                                   #Pack username entry for top frame  
        self.password_label.pack(side="left")                                                                   #Pack password label for middle frame
        self.password_entry.pack(side="left")                                                                   #Pack password entry for middle frame

        self.continue_button.pack(side="left")                                                                  #Pack continue button for bottom frame
        self.reset_button.pack(side="left")                                                                     #Pack reset button for bottom frame

        self.result_label.pack(side="left")                                                                     #Pack result label for lowest frame    

        self.top_frame.pack()                                                                                   #Pack top frame    
        self.middle_frame.pack()                                                                                #Pack middle frame      
        self.bottom_frame.pack()                                                                                #Pack bottom frame
        self.lowest_frame.pack()                                                                                #Pack lowest frame      

        tkinter.mainloop()                                                                                      #Enter tkinter main loop

    def Checker(self):                                                                   #This method encapsulates the code that checks the username and password
        username_value = str(self.username_entry.get())                                  #This code gets the username value from the username entry
        password_value = str(self.password_entry.get())                                  #This code gets the password value from the password entry

        if username_value == "admin" and password_value == "admin":                      #This code checks if the username and password are correct
            self.result.set("Welcome to the system")                                     #This code sets the result label to welcome to the system
            self.username_entry.delete(0, tkinter.END)                                   #This code deletes the username entry    
            self.password_entry.delete(0,tkinter.END)                                    #This code deletes the password entry
            main()                                                                       #This code calls the main function                    

        else:                                                                            #This code executes if the username and password are incorrect    
            self.Reset()                                                                 #This code calls the reset function

    def Reset(self):
        self.result.set("Invalid Username or Password")                                  #This code sets the result label to invalid username or password
        self.username_entry.delete(0, tkinter.END)                                       #This code deletes the username entry
        self.password_entry.delete(0,tkinter.END)                                        #This code deletes the password entry     

authenticate = Authenticate()                                                            #This code creates an object of the Authenticate class


    

        
        